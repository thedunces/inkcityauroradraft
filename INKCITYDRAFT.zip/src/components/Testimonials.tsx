import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';
import { Star } from 'lucide-react';
import backdrop from 'figma:asset/07b3a4b22a8786aec341d1997af37fc7cbfda713.png';

export function Testimonials() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const testimonials = [
    {
      name: 'Your mom!',
      text: 'The attention to detail is incredible. My sleeve took three sessions and the result is a true masterpiece. The artist really understood my vision.',
      rating: 5,
    },
    {
      name: 'Jesus Christ',
      text: 'Best tattoo experience I\'ve ever had. The studio is clean, professional, and the artists are world-class. My portrait tattoo looks exactly like the photo.',
      rating: 5,
    },
    {
      name: 'Girl Next Door',
      text: 'I\'ve gotten tattoos at many shops, but Ink City is on another level. The blackwork is bold and clean. These guys are true artists.',
      rating: 5,
    },
  ];

  return (
    <section id="testimonials" className="py-24 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${backdrop})` }}
        />
        <div className="absolute inset-0 bg-black/85" />
      </div>

      {/* Background Text Effect */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-9xl font-black text-white/5 whitespace-nowrap pointer-events-none">
        TESTIMONIALS
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="mb-16"
        >
          <h2 className="text-4xl sm:text-5xl md:text-6xl font-black mb-6">
            READ WHAT <span className="text-yellow-500">MY CLIENTS</span>
          </h2>
          <h3 className="text-4xl sm:text-5xl md:text-6xl font-black">
            SAY ABOUT MY WORK
          </h3>
        </motion.div>

        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 50 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.6, delay: index * 0.2 }}
              className="bg-zinc-900 p-8 border border-zinc-800 hover:border-yellow-500 transition-colors duration-300 group"
            >
              <div className="flex gap-1 mb-6">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star
                    key={i}
                    className="fill-yellow-500 text-yellow-500"
                    size={20}
                  />
                ))}
              </div>
              <p className="text-gray-300 text-lg mb-6 leading-relaxed">
                "{testimonial.text}"
              </p>
              <div className="border-t border-zinc-800 pt-4">
                <p className="text-yellow-500 tracking-wider uppercase">
                  {testimonial.name}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}