import { motion } from 'motion/react';
import { ChevronDown } from 'lucide-react';
import backdrop from 'figma:asset/07b3a4b22a8786aec341d1997af37fc7cbfda713.png';

export function Hero() {
  const textVariants = {
    hidden: { opacity: 0, y: 50 },
    visible: (custom: number) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: custom * 0.2,
        duration: 0.8,
        ease: 'easeOut',
      },
    }),
  };

  return (
    <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${backdrop})` }}
        />
        <div className="absolute inset-0 bg-black/80" />
      </div>

      {/* Animated Background Effects */}
      <div className="absolute inset-0">
        <motion.div
          animate={{
            scale: [1, 1.2, 1],
            rotate: [0, 90, 0],
          }}
          transition={{
            duration: 20,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-yellow-500/5 rounded-full blur-3xl"
        />
        <motion.div
          animate={{
            scale: [1.2, 1, 1.2],
            rotate: [90, 0, 90],
          }}
          transition={{
            duration: 15,
            repeat: Infinity,
            ease: 'linear',
          }}
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-yellow-500/5 rounded-full blur-3xl"
        />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-6xl mx-auto">
        <motion.div
          initial="hidden"
          animate="visible"
          className="space-y-6"
        >
          <motion.h1
            custom={0}
            variants={textVariants}
            className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-tighter"
          >
            REALISM
          </motion.h1>
          <motion.h2
            custom={1}
            variants={textVariants}
            className="text-6xl sm:text-7xl md:text-8xl lg:text-9xl font-black tracking-tighter"
          >
            BLACK & GREY
          </motion.h2>
          
          <motion.div
            custom={2}
            variants={textVariants}
            className="pt-8 space-y-4"
          >
            <p className="text-gray-400 text-lg sm:text-xl tracking-widest uppercase">
              Tattoo Studio • Ink City Aurora
            </p>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              className="bg-yellow-500 text-black px-10 py-4 text-lg tracking-wider uppercase hover:bg-yellow-400 transition-colors duration-300 inline-block"
            >
              Book a Session
            </motion.button>
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.div
        animate={{
          y: [0, 10, 0],
        }}
        transition={{
          duration: 1.5,
          repeat: Infinity,
          ease: 'easeInOut',
        }}
        className="absolute bottom-8 left-1/2 -translate-x-1/2"
      >
        <ChevronDown className="text-yellow-500" size={32} />
      </motion.div>
    </section>
  );
}