import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';
import { MapPin, Phone, Mail, Instagram, Facebook, Clock } from 'lucide-react';
import backdrop from 'figma:asset/07b3a4b22a8786aec341d1997af37fc7cbfda713.png';

export function Contact() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  return (
    <section id="contact" className="py-24 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${backdrop})` }}
        />
        <div className="absolute inset-0 bg-black/90" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl sm:text-6xl md:text-7xl font-black mb-4">
            GET IN <span className="text-yellow-500">TOUCH</span>
          </h2>
          <p className="text-gray-400 text-lg tracking-wide">
            Ready to start your tattoo journey? Let's create something amazing.
          </p>
        </motion.div>

        <div className="grid md:grid-cols-2 gap-12">
          {/* Contact Form */}
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
          >
            <form className="space-y-6">
              <div>
                <input
                  type="text"
                  placeholder="Your Name"
                  className="w-full bg-black border border-zinc-800 px-6 py-4 text-white placeholder-gray-600 focus:border-yellow-500 focus:outline-none transition-colors"
                />
              </div>
              <div>
                <input
                  type="email"
                  placeholder="Your Email"
                  className="w-full bg-black border border-zinc-800 px-6 py-4 text-white placeholder-gray-600 focus:border-yellow-500 focus:outline-none transition-colors"
                />
              </div>
              <div>
                <input
                  type="tel"
                  placeholder="Phone Number"
                  className="w-full bg-black border border-zinc-800 px-6 py-4 text-white placeholder-gray-600 focus:border-yellow-500 focus:outline-none transition-colors"
                />
              </div>
              <div>
                <textarea
                  placeholder="Tell us about your tattoo idea"
                  rows={6}
                  className="w-full bg-black border border-zinc-800 px-6 py-4 text-white placeholder-gray-600 focus:border-yellow-500 focus:outline-none transition-colors resize-none"
                ></textarea>
              </div>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                type="submit"
                className="w-full bg-yellow-500 text-black py-4 tracking-wider uppercase hover:bg-yellow-400 transition-colors duration-300"
              >
                Send Message
              </motion.button>
            </form>
          </motion.div>

          {/* Contact Information */}
          <motion.div
            initial={{ opacity: 0, x: 50 }}
            animate={inView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8 }}
            className="space-y-8"
          >
            <div className="space-y-6">
              <div className="flex items-start gap-4">
                <MapPin className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
                <div>
                  <h4 className="text-xl font-bold mb-1">Location</h4>
                  <p className="text-gray-400">
                    13690 E Iliff Ave Suite B<br />
                    Aurora, CO 80014
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Phone className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
                <div>
                  <h4 className="text-xl font-bold mb-1">Phone</h4>
                  <p className="text-gray-400">(303) 666-8==D</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Mail className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
                <div>
                  <h4 className="text-xl font-bold mb-1">Email</h4>
                  <p className="text-gray-400">info@inkcity.studio</p>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <Clock className="text-yellow-500 flex-shrink-0 mt-1" size={24} />
                <div>
                  <h4 className="text-xl font-bold mb-1">Hours</h4>
                  <p className="text-gray-400">
                    Mon - Sat: 11AM - 8PM<br />
                    Sun: 12PM - 6PM
                  </p>
                </div>
              </div>
            </div>

            <div className="pt-8 border-t border-zinc-800">
              <h4 className="text-xl font-bold mb-4">Follow Us</h4>
              <div className="flex gap-4">
                <motion.a
                  whileHover={{ scale: 1.1, color: '#eab308' }}
                  href="#"
                  className="bg-zinc-900 p-3 border border-zinc-800 hover:border-yellow-500 transition-colors"
                >
                  <Instagram size={24} />
                </motion.a>
                <motion.a
                  whileHover={{ scale: 1.1, color: '#eab308' }}
                  href="#"
                  className="bg-zinc-900 p-3 border border-zinc-800 hover:border-yellow-500 transition-colors"
                >
                  <Facebook size={24} />
                </motion.a>
              </div>
            </div>
          </motion.div>
        </div>
      </div>

      {/* Footer */}
      <div className="max-w-7xl mx-auto mt-24 pt-8 border-t border-zinc-800 text-center text-gray-600">
        <p>&copy; 2026 Ink City. All rights reserved.</p>
      </div>
    </section>
  );
}