import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';
import { useState } from 'react';
import { ImageWithFallback } from './figma/ImageWithFallback';
import { X } from 'lucide-react';
import tattoo1 from 'figma:asset/c2fb50fae0c47cecfaee53077e696bcd9282fbe4.png';
import tattoo2 from 'figma:asset/cb5559f8584b300944b5038dc80f4fc6204cf527.png';
import tattoo3 from 'figma:asset/a1611449df3ed3b180a0bb4db0d58d4bcf72153c.png';
import tattoo4 from 'figma:asset/a335a5511dbf17e47c6320a5ebcada245131b74d.png';
import tattoo5 from 'figma:asset/5c3cf727ee4fc408430f02894d429821c97252c9.png';
import tattoo6 from 'figma:asset/98049bc41609dd901f61977cfb1f87974512b48f.png';
import tattoo7 from 'figma:asset/1e81bc025a93816c0b4e1c205d8430423e5d9139.png';

export function Gallery() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const [selectedImage, setSelectedImage] = useState<string | null>(null);

  const galleryImages = [
    {
      url: tattoo1,
      alt: 'Horror realism tattoo',
    },
    {
      url: tattoo2,
      alt: 'Skull portrait tattoo',
    },
    {
      url: tattoo3,
      alt: 'Tiger and skull sleeve tattoo',
    },
    {
      url: tattoo4,
      alt: 'Japanese sleeve tattoo',
    },
    {
      url: tattoo5,
      alt: 'Religious portrait with rose tattoo',
    },
    {
      url: tattoo6,
      alt: 'Religious portrait with dove tattoo',
    },
    {
      url: tattoo7,
      alt: 'Jesus portrait tattoo',
    },
  ];

  return (
    <section id="gallery" className="py-24 px-4 bg-zinc-950">
      <div className="max-w-7xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl sm:text-6xl md:text-7xl font-black mb-4">
            OUR <span className="text-yellow-500">WORK</span>
          </h2>
          <p className="text-gray-400 text-lg tracking-wide">
            A glimpse into our portfolio of exceptional artistry
          </p>
        </motion.div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {galleryImages.map((image, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, scale: 0.9 }}
              animate={inView ? { opacity: 1, scale: 1 } : {}}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="relative overflow-hidden group cursor-pointer aspect-square"
              onClick={() => setSelectedImage(image.url)}
            >
              <ImageWithFallback
                src={image.url}
                alt={image.alt}
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                <span className="text-white text-lg tracking-wider uppercase">View</span>
              </div>
              <div className="absolute inset-0 border-2 border-yellow-500 opacity-0 group-hover:opacity-100 transition-opacity duration-300 scale-95" />
            </motion.div>
          ))}
        </div>

        {/* Lightbox */}
        {selectedImage && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/95 z-50 flex items-center justify-center p-4"
            onClick={() => setSelectedImage(null)}
          >
            <button
              className="absolute top-4 right-4 text-white hover:text-yellow-500 transition-colors"
              onClick={() => setSelectedImage(null)}
            >
              <X size={32} />
            </button>
            <motion.div
              initial={{ scale: 0.8 }}
              animate={{ scale: 1 }}
              className="max-w-5xl max-h-[90vh]"
            >
              <ImageWithFallback
                src={selectedImage}
                alt="Gallery image"
                className="w-full h-full object-contain"
              />
            </motion.div>
          </motion.div>
        )}
      </div>
    </section>
  );
}