import { motion } from 'motion/react';
import { useInView } from 'react-intersection-observer';
import { ImageWithFallback } from './figma/ImageWithFallback';
import tattoo1 from 'figma:asset/c2fb50fae0c47cecfaee53077e696bcd9282fbe4.png';
import tattoo2 from 'figma:asset/cb5559f8584b300944b5038dc80f4fc6204cf527.png';
import tattoo3 from 'figma:asset/a1611449df3ed3b180a0bb4db0d58d4bcf72153c.png';
import backdrop from 'figma:asset/07b3a4b22a8786aec341d1997af37fc7cbfda713.png';

export function Services() {
  const [ref, inView] = useInView({
    triggerOnce: true,
    threshold: 0.1,
  });

  const services = [
    {
      title: 'BLACKWORK & OLDSCHOOL',
      subtitle: 'EXPERT',
      description: 'Bold lines and traditional designs that stand the test of time. Our artists specialize in classic American traditional and modern blackwork techniques.',
      image: tattoo2,
    },
    {
      title: 'REALISM &',
      subtitle: 'PORTRAIT',
      description: 'Stunning photorealistic artwork that captures every detail. From portraits to wildlife, we bring your vision to life with incredible precision.',
      image: tattoo1,
    },
    {
      title: 'CUSTOM',
      subtitle: 'DESIGN',
      description: 'Collaborate with our artists to create a unique piece that tells your story. Every tattoo is a one-of-a-kind masterpiece.',
      image: tattoo3,
    },
  ];

  return (
    <section id="services" className="py-24 px-4 relative overflow-hidden">
      {/* Background */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0 bg-cover bg-center"
          style={{ backgroundImage: `url(${backdrop})` }}
        />
        <div className="absolute inset-0 bg-black/85" />
      </div>

      <div className="max-w-7xl mx-auto relative z-10">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={inView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="text-center mb-16"
        >
          <h2 className="text-5xl sm:text-6xl md:text-7xl font-black mb-4">
            OUR <span className="text-yellow-500">EXPERTISE</span>
          </h2>
          <p className="text-gray-400 text-lg tracking-wide">
            Specializing in multiple styles to bring your vision to life
          </p>
        </motion.div>

        <div className="space-y-24">
          {services.map((service, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 100 }}
              animate={inView ? { opacity: 1, y: 0 } : {}}
              transition={{ duration: 0.8, delay: index * 0.2 }}
              className={`grid md:grid-cols-2 gap-8 items-center ${
                index % 2 === 1 ? 'md:grid-flow-dense' : ''
              }`}
            >
              <div className={index % 2 === 1 ? 'md:col-start-2' : ''}>
                <div className="relative overflow-hidden group aspect-[4/3]">
                  <ImageWithFallback
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                </div>
              </div>
              
              <div className={`space-y-6 ${index % 2 === 1 ? 'md:col-start-1 md:row-start-1' : ''}`}>
                <div>
                  <h3 className="text-4xl sm:text-5xl md:text-6xl font-black leading-tight">
                    {service.title}
                  </h3>
                  <h4 className="text-4xl sm:text-5xl md:text-6xl font-black text-yellow-500">
                    {service.subtitle}
                  </h4>
                </div>
                <p className="text-gray-400 text-lg leading-relaxed">
                  {service.description}
                </p>
                <motion.button
                  whileHover={{ x: 10 }}
                  className="text-yellow-500 tracking-wider uppercase inline-flex items-center gap-2 group"
                >
                  Make an Appointment
                  <span className="group-hover:translate-x-2 transition-transform">→</span>
                </motion.button>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}