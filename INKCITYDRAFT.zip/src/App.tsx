import { Hero } from './components/Hero';
import { Services } from './components/Services';
import { Gallery } from './components/Gallery';
import { Testimonials } from './components/Testimonials';
import { Contact } from './components/Contact';
import { Navigation } from './components/Navigation';

export default function App() {
  return (
    <div className="bg-black text-white">
      <Navigation />
      <Hero />
      <Services />
      <Gallery />
      <Testimonials />
      <Contact />
    </div>
  );
}
