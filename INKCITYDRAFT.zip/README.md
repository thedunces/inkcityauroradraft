
  # Tattoo Shop Website Design

  This is a code bundle for Tattoo Shop Website Design. The original project is available at https://www.figma.com/design/LO46x77HEvJNi5wx80xe0H/Tattoo-Shop-Website-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  